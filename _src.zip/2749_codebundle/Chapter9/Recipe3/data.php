<?php
	sleep(2);
	echo '<p>This data has been <br/>loaded from server...</p>';
?>