<pre>
<?php
	print_r($_POST);

?>
</pre>